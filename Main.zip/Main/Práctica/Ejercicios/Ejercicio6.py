from Crypto.Hash import HMAC, SHA256

secret = bytes('2712A51C997E14B4DF08D55967641B0677CA31E049E672A4B06861AA4D5826EB', 'utf-8')

#Generación
msg0= bytes('Siempre existe más de una forma de hacerlo, y más de una solución válida.', 'utf-8')
h = HMAC.new(secret, msg=msg0, digestmod=SHA256)
#h.update(bytes('Hola', 'utf-8'))
print(h.hexdigest())
mac = h.hexdigest()

#Verificación
h2 = HMAC.new(secret, digestmod=SHA256)
msg = bytes('Siempre existe más de una forma de hacerlo, y más de una solución válida.', 'utf-8')
h2.update(msg)
try:
  h2.hexverify(mac)
  print("Mensaje validado ok")
except ValueError:
  print("Mensaje validado ko")