from Crypto.Cipher import ChaCha20_Poly1305
from base64 import b64decode, b64encode
from Crypto.Random import get_random_bytes
import json
import hashlib

try:

    textoPlano_bytes = bytes('Este curso es de lo mejor que podemos encontrar en el mercado', 'UTF-8')
    m = hashlib.sha256()
    m.update(bytes("Este curso es de lo mejor que podemos encontrar en el mercado", "utf8"))
    print("SHA256: " + m.digest().hex())
    #Se requiere o 256 o 128 bits de clave, por ello usamos 256 bits que se transforman en 64 caracteres hexadecimales
    clave_bytes = bytes.fromhex('979DF30474898787A45605CCB9B936D33B780D03CABC81719D52383480DC3120')
    #Importante NUNCA debe fijarse el nonce
    nonce_mensaje_bytes = bytes.fromhex('f5871c9ff7f99c926102dd92')
    #nonce_mensaje_bytes = get_random_bytes(12)
    #Con la clave y con el nonce se cifra. El nonce debe ser único por mensaje
    datos_asociados_bytes = bytes('Datos no cifrados sólo autenticados', 'utf-8')
    cipher = ChaCha20_Poly1305.new(key=clave_bytes, nonce=nonce_mensaje_bytes)
    cipher.update(datos_asociados_bytes)
    texto_cifrado_bytes, tag_bytes = cipher.encrypt_and_digest(textoPlano_bytes)
    #Simulamos el mensaje que se debe enviar, en este caso lo enviaremos todo el contenido en base64
    mensaje_enviado = { "nonce": b64encode(nonce_mensaje_bytes).decode(),"datos asociados": b64encode(datos_asociados_bytes).decode(), "texto cifrado": b64encode(texto_cifrado_bytes).decode(), "tag": b64encode(tag_bytes).decode()}
    json_mensaje = json.dumps(mensaje_enviado)
    print("Mensaje: ", json_mensaje)


    #Descifrado...

    tag_2 = b64decode("aHHhlvQQghds26HHha9Y/M==")
    #datos_asociados_bytes = bytes("Pepito grillo", "UTF-8")
    decipher = ChaCha20_Poly1305.new(key=clave_bytes, nonce=b64decode(mensaje_enviado["nonce"]))
    decipher.update(b64decode(mensaje_enviado["datos asociados"]))
    #decipher.update(datos_asociados_bytes)
    plaintext_bytes = decipher.decrypt_and_verify(b64decode(mensaje_enviado["texto cifrado"]),b64decode(mensaje_enviado["tag"]))
    #plaintext_bytes = decipher.decrypt_and_verify(b64decode(mensaje_enviado["texto cifrado"]),tag_2)
    print('Datos cifrados en claro = ',plaintext_bytes.decode('utf-8'))
except (ValueError, KeyError) as error: 
    print("Problemas al descifrar....")
    print("El motivo del error es: ", error)